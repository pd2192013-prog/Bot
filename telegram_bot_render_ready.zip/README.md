# Math Solver Telegram Bot — Render Ready

## Files
- `bot.py` — Telegram bot code
- `requirements.txt` — Python packages Render installs automatically
- `render.yaml` — Render deployment configuration

## Render
1. Upload/push these files to your GitHub repository root.
2. In Render, create a Background Worker from the repository (or use the Blueprint from `render.yaml`).
3. Render will run:
   `pip install -r requirements.txt`
4. Start command:
   `python bot.py`
5. Add these Environment Variables in Render:
   - `TELEGRAM_BOT_TOKEN`
   - `GEMINI_API_KEY`
   - Optional: `GEMINI_MODEL`

Do not put API keys inside the code or `requirements.txt`.
