# Render-ready Telegram bot

IMPORTANT:
Use Render's **New → Blueprint** flow with this repository. The root `render.yaml`
explicitly declares this as a Python Background Worker, so Render does not need
to guess the language from the repository.

Files:
- bot.py
- requirements.txt
- render.yaml
- .python-version

Render configuration:
- Runtime: Python
- Service type: Background Worker
- Build: pip install -r requirements.txt
- Start: python bot.py

Environment Variables:
- TELEGRAM_BOT_TOKEN = your Telegram bot token
- GEMINI_API_KEY = your Gemini API key
- GEMINI_MODEL = optional; leave blank to use the code default

Do not put secret keys in GitHub.
